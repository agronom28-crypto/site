import { useState, useEffect } from 'react';
import Head from 'next/head';
import { getProducts, getCategories } from '../../lib/api';
import Header from '../../components/Header';
import ProductCard from '../../components/ProductCard';
import Filter from '../../components/Filter';

export default function Catalog() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [filters, setFilters] = useState({
    category_id: null,
    min_price: null,
    max_price: null,
    search: '',
    sort_by: 'created_at',
    sort_order: 'desc'
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCategories();
  }, []);

  useEffect(() => {
    loadProducts();
  }, [filters]);

  const loadCategories = async () => {
    try {
      const res = await getCategories();
      setCategories(res.data);
    } catch (error) {
      console.error('Error loading categories:', error);
    }
  };

  const loadProducts = async () => {
    setLoading(true);
    try {
      const params = Object.fromEntries(
        Object.entries(filters).filter(([_, v]) => v != null && v !== '')
      );
      const res = await getProducts(params);
      setProducts(res.data);
    } catch (error) {
      console.error('Error loading products:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (newFilters) => {
    setFilters({ ...filters, ...newFilters });
  };

  return (
    <>
      <Head>
        <title>Каталог товаров</title>
      </Head>

      <Header />

      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Каталог товаров</h1>

        <div className="flex gap-6">
          {/* Sidebar with filters */}
          <aside className="w-64 flex-shrink-0">
            <Filter
              categories={categories}
              filters={filters}
              onChange={handleFilterChange}
            />
          </aside>

          {/* Products grid */}
          <div className="flex-1">
            {/* Sort controls */}
            <div className="flex justify-between items-center mb-6">
              <p className="text-gray-600">
                Найдено товаров: {products.length}
              </p>
              <select
                className="border rounded px-4 py-2"
                value={`${filters.sort_by}_${filters.sort_order}`}
                onChange={(e) => {
                  const [sort_by, sort_order] = e.target.value.split('_');
                  handleFilterChange({ sort_by, sort_order });
                }}
              >
                <option value="created_at_desc">Сначала новые</option>
                <option value="price_asc">Сначала дешевые</option>
                <option value="price_desc">Сначала дорогие</option>
                <option value="name_asc">По названию А-Я</option>
                <option value="sales_count_desc">Популярные</option>
              </select>
            </div>

            {/* Products */}
            {loading ? (
              <div className="text-center py-12">Загрузка...</div>
            ) : products.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                Товары не найдены
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </>
  );
}
