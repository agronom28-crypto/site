from sqlalchemy import Column, Integer, String, Text, ForeignKey
from sqlalchemy.orm import relationship
from app.db.base import Base

class Category(Base):
    __tablename__ = "categories"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    slug = Column(String, unique=True, index=True, nullable=False)
    description = Column(Text)
    parent_id = Column(Integer, ForeignKey("categories.id"), nullable=True)

    # Self-referential relationship
    parent = relationship("Category", remote_side=[id], back_populates="children")
    children = relationship("Category", back_populates="parent")

    # Products
    products = relationship("Product", back_populates="category")

    # SEO
    meta_title = Column(String)
    meta_description = Column(Text)
    meta_keywords = Column(String)

    # Display
    image = Column(String)
    order = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)

from sqlalchemy import Boolean
