from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, Enum
from datetime import datetime
import enum
from app.db.base import Base

class DiscountType(str, enum.Enum):
    percentage = "percentage"
    fixed = "fixed"

class PromoCode(Base):
    __tablename__ = "promo_codes"

    id = Column(Integer, primary_key=True, index=True)
    code = Column(String, unique=True, index=True, nullable=False)

    discount_type = Column(Enum(DiscountType), default=DiscountType.percentage)
    discount_value = Column(Float, nullable=False)  # % или фиксированная сумма

    min_order_amount = Column(Float, default=0)
    max_uses = Column(Integer, nullable=True)
    used_count = Column(Integer, default=0)

    is_active = Column(Boolean, default=True)
    valid_from = Column(DateTime, default=datetime.utcnow)
    valid_until = Column(DateTime, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)
