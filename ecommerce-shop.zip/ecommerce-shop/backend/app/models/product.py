from sqlalchemy import Column, Integer, String, Float, Boolean, Text, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime
from app.db.base import Base

class Product(Base):
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True, nullable=False)
    slug = Column(String, unique=True, index=True, nullable=False)
    description = Column(Text)

    # Pricing
    price = Column(Float, nullable=False)
    discount_price = Column(Float, nullable=True)

    # Stock
    stock = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)

    # Category
    category_id = Column(Integer, ForeignKey("categories.id"))
    category = relationship("Category", back_populates="products")

    # Product info
    manufacturer = Column(String)
    sku = Column(String, unique=True)

    # Specifications (JSON as text)
    specifications = Column(Text)  # JSON: {"weight": "100g", "color": "red"}

    # Images
    main_image = Column(String)
    images = Column(Text)  # JSON array: ["img1.jpg", "img2.jpg"]

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    reviews = relationship("Review", back_populates="product")
    order_items = relationship("OrderItem", back_populates="product")

    # SEO
    meta_title = Column(String)
    meta_description = Column(Text)
    meta_keywords = Column(String)

    # Stats
    views_count = Column(Integer, default=0)
    sales_count = Column(Integer, default=0)
