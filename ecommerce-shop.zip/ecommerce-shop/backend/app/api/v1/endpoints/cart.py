from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.core.deps import get_db, get_current_user
from app.models.cart import CartItem
from app.models.product import Product
from app.models.user import User

router = APIRouter()

@router.get("/")
def get_cart(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Получить корзину текущего пользователя"""
    cart_items = db.query(CartItem).filter(
        CartItem.user_id == current_user.id
    ).all()

    items_data = []
    total = 0

    for item in cart_items:
        product = item.product
        item_total = product.price * item.quantity
        total += item_total

        items_data.append({
            "id": item.id,
            "product_id": product.id,
            "product_name": product.name,
            "product_image": product.main_image,
            "price": product.price,
            "quantity": item.quantity,
            "total": item_total
        })

    return {
        "items": items_data,
        "total": total,
        "count": len(items_data)
    }

@router.post("/add/{product_id}")
def add_to_cart(
    product_id: int,
    quantity: int = 1,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Добавить товар в корзину"""
    # Проверяем товар
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    if not product.is_active:
        raise HTTPException(status_code=400, detail="Product is not available")

    if product.stock < quantity:
        raise HTTPException(status_code=400, detail="Not enough stock")

    # Проверяем, есть ли уже в корзине
    cart_item = db.query(CartItem).filter(
        CartItem.user_id == current_user.id,
        CartItem.product_id == product_id
    ).first()

    if cart_item:
        # Увеличиваем количество
        new_quantity = cart_item.quantity + quantity
        if product.stock < new_quantity:
            raise HTTPException(status_code=400, detail="Not enough stock")
        cart_item.quantity = new_quantity
    else:
        # Создаем новый элемент
        cart_item = CartItem(
            user_id=current_user.id,
            product_id=product_id,
            quantity=quantity
        )
        db.add(cart_item)

    db.commit()
    return {"message": "Product added to cart", "cart_item_id": cart_item.id}

@router.put("/update/{cart_item_id}")
def update_cart_item(
    cart_item_id: int,
    quantity: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Обновить количество товара в корзине"""
    cart_item = db.query(CartItem).filter(
        CartItem.id == cart_item_id,
        CartItem.user_id == current_user.id
    ).first()

    if not cart_item:
        raise HTTPException(status_code=404, detail="Cart item not found")

    if quantity <= 0:
        db.delete(cart_item)
        db.commit()
        return {"message": "Cart item removed"}

    if cart_item.product.stock < quantity:
        raise HTTPException(status_code=400, detail="Not enough stock")

    cart_item.quantity = quantity
    db.commit()
    return {"message": "Cart item updated"}

@router.delete("/remove/{cart_item_id}")
def remove_from_cart(
    cart_item_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Удалить товар из корзины"""
    cart_item = db.query(CartItem).filter(
        CartItem.id == cart_item_id,
        CartItem.user_id == current_user.id
    ).first()

    if not cart_item:
        raise HTTPException(status_code=404, detail="Cart item not found")

    db.delete(cart_item)
    db.commit()
    return {"message": "Item removed from cart"}

@router.delete("/clear")
def clear_cart(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Очистить всю корзину"""
    db.query(CartItem).filter(CartItem.user_id == current_user.id).delete()
    db.commit()
    return {"message": "Cart cleared"}
