from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.core.deps import get_db, get_current_user, get_current_superuser
from app.models.order import Order, OrderItem, OrderStatus
from app.models.cart import CartItem
from app.models.product import Product
from app.models.user import User
from app.schemas.order import OrderCreate, Order as OrderSchema

router = APIRouter()

@router.post("/create", response_model=OrderSchema)
def create_order(
    order_data: OrderCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Создать заказ из корзины"""
    # Получаем товары из корзины
    cart_items = db.query(CartItem).filter(
        CartItem.user_id == current_user.id
    ).all()

    if not cart_items:
        raise HTTPException(status_code=400, detail="Cart is empty")

    # Проверяем наличие товаров
    for cart_item in cart_items:
        if cart_item.product.stock < cart_item.quantity:
            raise HTTPException(
                status_code=400,
                detail=f"Not enough stock for product: {cart_item.product.name}"
            )

    # Считаем сумму
    total = sum(item.product.price * item.quantity for item in cart_items)
    discount = 0

    # TODO: Применить промокод если есть
    # if order_data.promo_code:
    #     discount = calculate_discount(order_data.promo_code, total)

    final_amount = total - discount

    # Создаем заказ
    order = Order(
        user_id=current_user.id,
        total_amount=total,
        discount_amount=discount,
        final_amount=final_amount,
        delivery_address=order_data.delivery_address,
        delivery_city=order_data.delivery_city,
        delivery_zipcode=order_data.delivery_zipcode,
        phone=order_data.phone,
        customer_name=order_data.customer_name,
        notes=order_data.notes,
        payment_method=order_data.payment_method,
        promo_code=order_data.promo_code,
        status=OrderStatus.pending
    )
    db.add(order)
    db.flush()

    # Создаем позиции заказа
    for cart_item in cart_items:
        order_item = OrderItem(
            order_id=order.id,
            product_id=cart_item.product_id,
            quantity=cart_item.quantity,
            price=cart_item.product.price
        )
        db.add(order_item)

        # Уменьшаем остаток
        cart_item.product.stock -= cart_item.quantity
        cart_item.product.sales_count += cart_item.quantity

    # Очищаем корзину
    db.query(CartItem).filter(CartItem.user_id == current_user.id).delete()

    db.commit()
    db.refresh(order)

    # TODO: Отправить email уведомление
    # send_order_confirmation_email(order.id, current_user.email)

    return order

@router.get("/", response_model=List[OrderSchema])
def get_user_orders(
    skip: int = 0,
    limit: int = 20,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Получить заказы пользователя"""
    orders = db.query(Order).filter(
        Order.user_id == current_user.id
    ).order_by(Order.created_at.desc()).offset(skip).limit(limit).all()
    return orders

@router.get("/{order_id}", response_model=OrderSchema)
def get_order(
    order_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Получить заказ по ID"""
    order = db.query(Order).filter(
        Order.id == order_id,
        Order.user_id == current_user.id
    ).first()

    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    return order

@router.post("/{order_id}/repeat")
def repeat_order(
    order_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Повторить заказ (добавить товары в корзину)"""
    # Получаем заказ
    order = db.query(Order).filter(
        Order.id == order_id,
        Order.user_id == current_user.id
    ).first()

    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    # Добавляем товары в корзину
    for item in order.items:
        # Проверяем наличие товара
        product = db.query(Product).filter(Product.id == item.product_id).first()
        if not product or not product.is_active:
            continue

        if product.stock < item.quantity:
            continue

        # Проверяем, есть ли уже в корзине
        cart_item = db.query(CartItem).filter(
            CartItem.user_id == current_user.id,
            CartItem.product_id == item.product_id
        ).first()

        if cart_item:
            cart_item.quantity += item.quantity
        else:
            cart_item = CartItem(
                user_id=current_user.id,
                product_id=item.product_id,
                quantity=item.quantity
            )
            db.add(cart_item)

    db.commit()
    return {"message": "Order items added to cart"}

@router.patch("/{order_id}/status")
def update_order_status(
    order_id: int,
    status: OrderStatus,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_superuser)
):
    """Обновить статус заказа (только админ)"""
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    order.status = status
    db.commit()

    # TODO: Отправить уведомление пользователю

    return {"message": "Order status updated", "status": status}

@router.get("/admin/all", response_model=List[OrderSchema])
def get_all_orders(
    skip: int = 0,
    limit: int = 50,
    status: OrderStatus = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_superuser)
):
    """Получить все заказы (только админ)"""
    query = db.query(Order)

    if status:
        query = query.filter(Order.status == status)

    orders = query.order_by(Order.created_at.desc()).offset(skip).limit(limit).all()
    return orders
