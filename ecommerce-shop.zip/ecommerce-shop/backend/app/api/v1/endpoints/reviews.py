from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.core.deps import get_db, get_current_user
from app.models.review import Review
from app.models.product import Product
from app.models.user import User
from app.schemas.review import ReviewCreate, Review as ReviewSchema

router = APIRouter()

@router.get("/product/{product_id}", response_model=List[ReviewSchema])
def get_product_reviews(
    product_id: int,
    skip: int = 0,
    limit: int = 20,
    db: Session = Depends(get_db)
):
    """Получить отзывы товара"""
    reviews = db.query(Review).filter(
        Review.product_id == product_id,
        Review.is_approved == True
    ).order_by(Review.created_at.desc()).offset(skip).limit(limit).all()
    return reviews

@router.post("/", response_model=ReviewSchema)
def create_review(
    review: ReviewCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Создать отзыв"""
    # Проверяем товар
    product = db.query(Product).filter(Product.id == review.product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    # Проверяем, не оставлял ли пользователь уже отзыв
    existing_review = db.query(Review).filter(
        Review.product_id == review.product_id,
        Review.user_id == current_user.id
    ).first()

    if existing_review:
        raise HTTPException(status_code=400, detail="You already reviewed this product")

    # Создаем отзыв
    db_review = Review(
        **review.model_dump(),
        user_id=current_user.id,
        is_approved=True  # Автоматическое одобрение, можно изменить на False
    )
    db.add(db_review)
    db.commit()
    db.refresh(db_review)

    return db_review

@router.get("/my", response_model=List[ReviewSchema])
def get_my_reviews(
    skip: int = 0,
    limit: int = 20,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Получить мои отзывы"""
    reviews = db.query(Review).filter(
        Review.user_id == current_user.id
    ).order_by(Review.created_at.desc()).offset(skip).limit(limit).all()
    return reviews
