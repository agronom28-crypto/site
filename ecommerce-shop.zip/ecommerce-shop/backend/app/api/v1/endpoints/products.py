from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, File
from sqlalchemy.orm import Session
from typing import List, Optional
import json

from app.core.deps import get_db, get_current_superuser
from app.models.product import Product
from app.schemas.product import Product as ProductSchema, ProductCreate, ProductUpdate

router = APIRouter()

@router.get("/", response_model=List[ProductSchema])
def get_products(
    skip: int = 0,
    limit: int = 20,
    category_id: Optional[int] = None,
    search: Optional[str] = None,
    min_price: Optional[float] = None,
    max_price: Optional[float] = None,
    manufacturer: Optional[str] = None,
    sort_by: str = Query("created_at", regex="^(price|created_at|name|sales_count)$"),
    sort_order: str = Query("desc", regex="^(asc|desc)$"),
    db: Session = Depends(get_db)
):
    """Получить список товаров с фильтрацией и сортировкой"""
    query = db.query(Product).filter(Product.is_active == True)

    # Фильтры
    if category_id:
        query = query.filter(Product.category_id == category_id)
    if search:
        query = query.filter(Product.name.ilike(f"%{search}%"))
    if min_price is not None:
        query = query.filter(Product.price >= min_price)
    if max_price is not None:
        query = query.filter(Product.price <= max_price)
    if manufacturer:
        query = query.filter(Product.manufacturer == manufacturer)

    # Сортировка
    order_col = getattr(Product, sort_by)
    if sort_order == "desc":
        query = query.order_by(order_col.desc())
    else:
        query = query.order_by(order_col.asc())

    total = query.count()
    products = query.offset(skip).limit(limit).all()

    return products

@router.get("/{product_id}", response_model=ProductSchema)
def get_product(product_id: int, db: Session = Depends(get_db)):
    """Получить товар по ID"""
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    # Увеличиваем счетчик просмотров
    product.views_count += 1
    db.commit()

    return product

@router.get("/slug/{slug}", response_model=ProductSchema)
def get_product_by_slug(slug: str, db: Session = Depends(get_db)):
    """Получить товар по slug"""
    product = db.query(Product).filter(Product.slug == slug).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    product.views_count += 1
    db.commit()

    return product

@router.post("/", response_model=ProductSchema)
def create_product(
    product: ProductCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_superuser)
):
    """Создать товар (только админ)"""
    # Проверяем уникальность slug
    existing = db.query(Product).filter(Product.slug == product.slug).first()
    if existing:
        raise HTTPException(status_code=400, detail="Product with this slug already exists")

    db_product = Product(**product.model_dump())
    db.add(db_product)
    db.commit()
    db.refresh(db_product)
    return db_product

@router.put("/{product_id}", response_model=ProductSchema)
def update_product(
    product_id: int,
    product: ProductUpdate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_superuser)
):
    """Обновить товар (только админ)"""
    db_product = db.query(Product).filter(Product.id == product_id).first()
    if not db_product:
        raise HTTPException(status_code=404, detail="Product not found")

    for key, value in product.model_dump(exclude_unset=True).items():
        setattr(db_product, key, value)

    db.commit()
    db.refresh(db_product)
    return db_product

@router.delete("/{product_id}")
def delete_product(
    product_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_superuser)
):
    """Удалить товар (только админ)"""
    db_product = db.query(Product).filter(Product.id == product_id).first()
    if not db_product:
        raise HTTPException(status_code=404, detail="Product not found")

    db.delete(db_product)
    db.commit()
    return {"message": "Product deleted successfully"}

@router.get("/manufacturers/list")
def get_manufacturers(db: Session = Depends(get_db)):
    """Получить список всех производителей"""
    manufacturers = db.query(Product.manufacturer).distinct().filter(
        Product.manufacturer.isnot(None)
    ).all()
    return [m[0] for m in manufacturers]
