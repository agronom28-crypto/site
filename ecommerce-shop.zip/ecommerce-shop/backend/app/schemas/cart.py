from pydantic import BaseModel

class CartItemCreate(BaseModel):
    product_id: int
    quantity: int = 1

class CartItemUpdate(BaseModel):
    quantity: int

class CartItemInDB(BaseModel):
    id: int
    product_id: int
    quantity: int

    class Config:
        from_attributes = True
