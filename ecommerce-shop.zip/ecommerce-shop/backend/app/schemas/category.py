from pydantic import BaseModel
from typing import Optional, List

class CategoryBase(BaseModel):
    name: str
    slug: str
    description: Optional[str] = None
    parent_id: Optional[int] = None
    image: Optional[str] = None
    order: int = 0

class CategoryCreate(CategoryBase):
    pass

class CategoryUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    image: Optional[str] = None
    order: Optional[int] = None

class CategoryInDB(CategoryBase):
    id: int
    is_active: bool

    class Config:
        from_attributes = True

class Category(CategoryInDB):
    children: List['Category'] = []

Category.model_rebuild()
