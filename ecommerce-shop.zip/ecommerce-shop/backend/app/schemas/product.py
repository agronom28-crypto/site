from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

class ProductBase(BaseModel):
    name: str
    slug: str
    description: Optional[str] = None
    price: float
    discount_price: Optional[float] = None
    stock: int = 0
    category_id: int
    manufacturer: Optional[str] = None
    sku: Optional[str] = None
    specifications: Optional[str] = None
    main_image: Optional[str] = None
    images: Optional[str] = None
    meta_title: Optional[str] = None
    meta_description: Optional[str] = None
    meta_keywords: Optional[str] = None

class ProductCreate(ProductBase):
    pass

class ProductUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    price: Optional[float] = None
    discount_price: Optional[float] = None
    stock: Optional[int] = None
    is_active: Optional[bool] = None
    main_image: Optional[str] = None

class ProductInDB(ProductBase):
    id: int
    is_active: bool
    views_count: int
    sales_count: int
    created_at: datetime

    class Config:
        from_attributes = True

class Product(ProductInDB):
    pass
