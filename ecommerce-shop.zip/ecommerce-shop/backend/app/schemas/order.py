from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from app.models.order import OrderStatus, PaymentStatus

class OrderItemCreate(BaseModel):
    product_id: int
    quantity: int
    price: float

class OrderItemInDB(OrderItemCreate):
    id: int
    order_id: int

    class Config:
        from_attributes = True

class OrderCreate(BaseModel):
    delivery_address: str
    delivery_city: str
    delivery_zipcode: Optional[str] = None
    phone: str
    customer_name: str
    notes: Optional[str] = None
    payment_method: str
    promo_code: Optional[str] = None

class OrderInDB(BaseModel):
    id: int
    user_id: int
    status: OrderStatus
    total_amount: float
    discount_amount: float
    final_amount: float
    delivery_address: str
    phone: str
    payment_status: PaymentStatus
    created_at: datetime
    items: List[OrderItemInDB] = []

    class Config:
        from_attributes = True

class Order(OrderInDB):
    pass
