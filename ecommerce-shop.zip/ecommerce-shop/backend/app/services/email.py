import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from jinja2 import Template

from app.core.config import settings

def send_email(to_email: str, subject: str, html_content: str):
    """Отправить email"""
    msg = MIMEMultipart('alternative')
    msg['Subject'] = subject
    msg['From'] = f"{settings.EMAILS_FROM_NAME} <{settings.EMAILS_FROM_EMAIL}>"
    msg['To'] = to_email

    html_part = MIMEText(html_content, 'html')
    msg.attach(html_part)

    try:
        with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT) as server:
            server.starttls()
            server.login(settings.SMTP_USER, settings.SMTP_PASSWORD)
            server.send_message(msg)
        return True
    except Exception as e:
        print(f"Error sending email: {e}")
        return False

def send_order_confirmation(order_id: int, to_email: str, order_details: dict):
    """Отправить подтверждение заказа"""
    template = Template('''
    <html>
    <body style="font-family: Arial, sans-serif;">
        <h2>Спасибо за ваш заказ!</h2>
        <p>Номер заказа: <strong>#{{ order_id }}</strong></p>
        <p>Сумма: <strong>{{ total }} ₽</strong></p>

        <h3>Товары:</h3>
        <ul>
        {% for item in items %}
            <li>{{ item.name }} x {{ item.quantity }} = {{ item.total }} ₽</li>
        {% endfor %}
        </ul>

        <p>Мы свяжемся с вами для подтверждения заказа.</p>

        <p>С уважением,<br>{{ shop_name }}</p>
    </body>
    </html>
    ''')

    html = template.render(
        order_id=order_id,
        total=order_details.get('total', 0),
        items=order_details.get('items', []),
        shop_name=settings.EMAILS_FROM_NAME
    )

    return send_email(to_email, f"Заказ #{order_id} оформлен", html)
