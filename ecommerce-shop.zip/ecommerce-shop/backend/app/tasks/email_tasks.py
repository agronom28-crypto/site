from app.tasks.celery_app import celery_app
from app.services.email import send_order_confirmation
from app.db.session import SessionLocal
from app.models.order import Order

@celery_app.task
def send_order_email(order_id: int, to_email: str):
    """Отправить email о заказе (асинхронно)"""
    db = SessionLocal()
    try:
        order = db.query(Order).filter(Order.id == order_id).first()
        if not order:
            return False

        order_details = {
            'total': order.final_amount,
            'items': [
                {
                    'name': item.product.name,
                    'quantity': item.quantity,
                    'total': item.price * item.quantity
                }
                for item in order.items
            ]
        }

        return send_order_confirmation(order_id, to_email, order_details)
    finally:
        db.close()
